#' The NYS Geographic Aggregation Tool (GAT)
#'
#'
#' @description
#' A method for easily aggregating spatial data using user-defined
#' parameters with minimal knowledge of or experience using R.
#'
#' @name gatpkg
# @aliases GAT
#'
#' @details
#'
#' GAT's goals:
#' \itemize{
#'   \item simplify geographic aggregation
#'   \item be in a format accessible to anyone
#'   \item not require prior experience with R
#'   \item be customizable for advanced R users
#'   \item standardize the aggregation process
#' }
#'
#' To run the default version of GAT, follow the
#' \href{../doc/gat_tutorial.html}{GAT walkthrough} in the vignettes.
#'
#' For information about how GAT works, check out the
#' \href{../doc/gat_tech_notes.html}{GAT technical notes}.
#'
#' GAT was made possible through funding made available to the New York State
#' Department of Health / HRI by the CDC through grant # NUE1EH001341-03-01.
#' Its content is solely the responsibility of the authors and does not
#' necessarily represent the official views of the CDC.
#'
#'
#'
#'
#'
#'
#' @author
#'  Abigail Stamm, Bureau of Environmental and Occupational
#'                 Epidemiology, New York State Department of Health \cr
#'  Gwen Babcock, Bureau of Environmental and Occupational
#'                Epidemiology, New York State Department of Health \cr
#'
#'
#'  \bold{Alpha-testers} \cr
#'  Neil Muscatiello, Bureau of Environmental and Occupational
#'                    Epidemiology, New York State Department of Health \cr
#'  Arjita Rai, Bureau of Environmental and Occupational
#'              Epidemiology, New York State Department of Health \cr
#'  Catherine Wargo, Bureau of Environmental and Occupational
#'                   Epidemiology, New York State Department of Health \cr
#'  Christophe Maxime Fokoua Dongmo, Bureau of Environmental and Occupational
#'                    Epidemiology, New York State Department of Health \cr
#'  Marine Nalbandyan, Bureau of Environmental and Occupational
#'                     Epidemiology, New York State Department of Health
#'                     (former) \cr
#'
#'
#'  \bold{Beta-testers} \cr
#'  Angela Werner, Centers for Disease Control and Prevention \cr
#'
#'  \bold{Other contributors} \cr
#'  Douglas Done, Bureau of Environmental and Occupational Epidemiology,
#'                New York State Department of Health \cr
#'  Thomas Talbot, Bureau of Environmental and Occupational Epidemiology,
#'                 New York State Department of Health (retired) \cr
#'
#'
#'
#'
#'

# mostly, I copied dplyr at https://github.com/tidyverse/dplyr/blob/master/R/dplyr.r
# I borrowed authorship code from https://rdrr.io/cran/TLdating/src/R/TLdating-package.R
# dplyr and TLdating put namespace code here
NULL
